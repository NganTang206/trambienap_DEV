/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { useReducer } from "react";
import { Bulk } from "../Bulk";
import { Linear } from "../Linear";
import "./style.css";

export const Item = ({
  property1,
  propertyHtClassName,
  bulkPropertyHeThong = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk@2x.png",
}) => {
  const [state, dispatch] = useReducer(reducer, {
    property1: property1 || "HT-default",
  });

  return (
    <>
      {(state.property1 === "DM-default" ||
        state.property1 === "DM-selected" ||
        state.property1 === "DN-default" ||
        state.property1 === "DN-selected" ||
        state.property1 === "HT-default" ||
        state.property1 === "HT-selected" ||
        state.property1 === "change-pass" ||
        state.property1 === "changepass-hover" ||
        state.property1 === "idm-default" ||
        state.property1 === "idm-selected" ||
        state.property1 === "iht-default" ||
        state.property1 === "iht-selected" ||
        state.property1 === "pass") && (
        <div
          className={`item property-HT ${state.property1} ${propertyHtClassName}`}
          onMouseEnter={() => {
            dispatch("mouse_enter");
          }}
          onMouseLeave={() => {
            dispatch("mouse_leave");
          }}
        >
          {["HT-default", "HT-selected"].includes(state.property1) && (
            <Bulk
              className="bulk-instance"
              property1="he-thong"
              propertyHeThong="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk@2x.png"
            />
          )}

          {["DM-default", "DM-selected", "idm-default", "idm-selected", "iht-default", "iht-selected"].includes(
            state.property1
          ) && (
            <Bulk
              className="bulk-instance"
              property1={["iht-default", "iht-selected"].includes(state.property1) ? "he-thong" : "danh-muc"}
              propertyDanhMuc={
                ["DM-default", "DM-selected", "idm-default", "idm-selected"].includes(state.property1)
                  ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk-2@2x.png"
                  : undefined
              }
              propertyHeThong={bulkPropertyHeThong}
            />
          )}

          {["DM-default", "DM-selected", "HT-default", "HT-selected"].includes(state.property1) && (
            <div className="div">
              {["HT-default", "HT-selected"].includes(state.property1) && <>Hệ Thống</>}

              {["DM-default", "DM-selected"].includes(state.property1) && <>Danh Mục</>}
            </div>
          )}

          {["DN-default", "DN-selected", "HT-default", "HT-selected"].includes(state.property1) && (
            <img
              className="chevron-down"
              alt="Chevron down"
              src={
                ["DN-default", "DN-selected"].includes(state.property1)
                  ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-47@2x.png"
                  : "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-down-7@2x.png"
              }
            />
          )}

          {["DN-default", "DN-selected"].includes(state.property1) && <div className="text-wrapper">Đăng nhập</div>}

          {state.property1 === "pass" && (
            <>
              <div className="div-2">
                <img
                  className="img"
                  alt="Bulk"
                  src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk@2x.png"
                />
                <div className="div">Hệ Thống</div>
                <img
                  className="chevron-down-2"
                  alt="Chevron down"
                  src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-down@2x.png"
                />
              </div>
              <div className="div-3">
                <Linear className="linear-instance" property1="security-safe" />
                <div className="text-wrapper-2">Thay đổi mật khẩu</div>
                <div className="rectangle" />
              </div>
            </>
          )}

          {["change-pass", "changepass-hover"].includes(state.property1) && (
            <>
              <Linear className="linear-instance" property1="security-safe" />
              <div className="text-wrapper-2">Thay đổi mật khẩu</div>
              <div className="rectangle" />
            </>
          )}
        </div>
      )}

      {["idn-default", "idn-selected"].includes(state.property1) && (
        <img
          className={`item property-idn property-1-0-${state.property1} ${propertyHtClassName}`}
          alt="Property idn"
          src={
            state.property1 === "idn-selected"
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-idn-selected@2x.png"
              : "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-idn-default@2x.png"
          }
        />
      )}
    </>
  );
};

function reducer(state, action) {
  if (state.property1 === "HT-default") {
    switch (action) {
      case "mouse_enter":
        return {
          property1: "HT-selected",
        };
    }
  }

  if (state.property1 === "HT-selected") {
    switch (action) {
      case "mouse_leave":
        return {
          property1: "HT-default",
        };
    }
  }

  if (state.property1 === "DM-default") {
    switch (action) {
      case "mouse_enter":
        return {
          property1: "DM-selected",
        };
    }
  }

  if (state.property1 === "DM-selected") {
    switch (action) {
      case "mouse_leave":
        return {
          property1: "DM-default",
        };
    }
  }

  if (state.property1 === "iht-default") {
    switch (action) {
      case "mouse_enter":
        return {
          property1: "iht-selected",
        };
    }
  }

  if (state.property1 === "iht-selected") {
    switch (action) {
      case "mouse_leave":
        return {
          property1: "iht-default",
        };
    }
  }

  if (state.property1 === "idm-default") {
    switch (action) {
      case "mouse_enter":
        return {
          property1: "idm-selected",
        };
    }
  }

  if (state.property1 === "idm-selected") {
    switch (action) {
      case "mouse_leave":
        return {
          property1: "idm-default",
        };
    }
  }

  if (state.property1 === "DN-default") {
    switch (action) {
      case "mouse_enter":
        return {
          property1: "DN-selected",
        };
    }
  }

  if (state.property1 === "DN-selected") {
    switch (action) {
      case "mouse_leave":
        return {
          property1: "DN-default",
        };
    }
  }

  if (state.property1 === "change-pass") {
    switch (action) {
      case "mouse_enter":
        return {
          property1: "changepass-hover",
        };
    }
  }

  if (state.property1 === "changepass-hover") {
    switch (action) {
      case "mouse_leave":
        return {
          property1: "change-pass",
        };
    }
  }

  return state;
}

Item.propTypes = {
  property1: PropTypes.oneOf([
    "iht-default",
    "HT-default",
    "idm-selected",
    "idn-default",
    "DN-selected",
    "DN-default",
    "HT-selected",
    "DM-default",
    "idm-default",
    "idn-selected",
    "pass",
    "DM-selected",
    "change-pass",
    "changepass-hover",
    "iht-selected",
  ]),
  bulkPropertyHeThong: PropTypes.string,
};
