import { FilterBar } from ".";

export default {
  title: "Components/FilterBar",
  component: FilterBar,
  argTypes: {
    property1: {
      options: ["variant-4", "dropdown", "selected", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "variant-4",
    className: {},
    textFieldClassName: {},
    textFieldTextClassName: {},
    textClassName: {},
    linearPropertyChNhSAClassName: {},
  },
};
