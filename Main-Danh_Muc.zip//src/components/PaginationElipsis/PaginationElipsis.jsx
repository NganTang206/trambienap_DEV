/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const PaginationElipsis = ({
  className,
  paginationElipsis = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/pagination-elipsis-3@2x.png",
}) => {
  return <img className={`pagination-elipsis ${className}`} alt="Pagination elipsis" src={paginationElipsis} />;
};

PaginationElipsis.propTypes = {
  paginationElipsis: PropTypes.string,
};
