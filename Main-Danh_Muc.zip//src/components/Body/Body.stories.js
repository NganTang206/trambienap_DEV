import { Body } from ".";

export default {
  title: "Components/Body",
  component: Body,
};

export const Default = {
  args: {
    className: {},
    tableMaskClassName: {},
    paginationLengthLongClassName: {},
  },
};
