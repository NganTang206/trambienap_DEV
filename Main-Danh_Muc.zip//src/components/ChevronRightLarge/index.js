export { ChevronRightLarge } from "./ChevronRightLarge";
