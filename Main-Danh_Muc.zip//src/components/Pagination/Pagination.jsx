/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { PaginationArrow } from "../PaginationArrow";
import { PaginationElipsis } from "../PaginationElipsis";
import { PaginationItem } from "../PaginationItem";
import { StateDefaultWrapper } from "../StateDefaultWrapper";
import "./style.css";

export const Pagination = ({ length, className }) => {
  return (
    <div className={`pagination ${length} ${className}`}>
      <PaginationArrow className="pagination-arrow-instance" state="disabled" />
      <PaginationItem className="pagination-item-instance" divClassName="pagination-item-2" state="selected" text="1" />
      <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="2" />
      <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="3" />
      <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="4" />
      <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="5" />
      {length === "short" && (
        <PaginationElipsis
          className="pagination-elipsis-instance"
          paginationElipsis="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/pagination-elipsis@2x.png"
        />
      )}

      <PaginationItem
        className="pagination-item-3"
        divClassName="pagination-item-4"
        state="default"
        text={length === "long" ? "6" : "10"}
      />
      {length === "short" && (
        <StateDefaultWrapper
          chevronRightLargeChevronRightLarge="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-right-large@2x.png"
          className="pagination-arrow-instance"
          state="default"
        />
      )}

      {length === "long" && (
        <>
          <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="7" />
          <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="8" />
          <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="9" />
          <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="10" />
          <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="11" />
          <PaginationElipsis
            className="pagination-elipsis-instance"
            paginationElipsis="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/pagination-elipsis@2x.png"
          />
          <PaginationItem className="pagination-item-3" divClassName="pagination-item-4" state="default" text="20" />
          <StateDefaultWrapper
            chevronRightLargeChevronRightLarge="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-right-large@2x.png"
            className="pagination-arrow-instance"
            state="default"
          />
        </>
      )}
    </div>
  );
};

Pagination.propTypes = {
  length: PropTypes.oneOf(["long", "short"]),
};
