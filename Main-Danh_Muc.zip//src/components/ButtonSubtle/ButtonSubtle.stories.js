import { ButtonSubtle } from ".";

export default {
  title: "Components/ButtonSubtle",
  component: ButtonSubtle,
  argTypes: {
    icon: {
      options: ["none", "only", "before"],
      control: { type: "select" },
    },
    stateProp: {
      options: ["hover", "active", "default"],
      control: { type: "select" },
    },
    spacing: {
      options: ["compact", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    icon: "none",
    stateProp: "hover",
    spacing: "compact",
    loading: true,
    className: {},
    linearPropertyChNhSA:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear@2x.png",
    text: "Label",
  },
};
