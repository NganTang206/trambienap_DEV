import { ButtonPrimary } from ".";

export default {
  title: "Components/ButtonPrimary",
  component: ButtonPrimary,
  argTypes: {
    icon: {
      options: ["none", "only", "before"],
      control: { type: "select" },
    },
    stateProp: {
      options: ["hover", "active", "default"],
      control: { type: "select" },
    },
    spacing: {
      options: ["compact", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    icon: "none",
    stateProp: "hover",
    spacing: "compact",
    loading: true,
    className: {},
    linearProperty1: "ch-nh-s-a",
    linearPropertyAdd: "abc",
    text: "Label",
  },
};
