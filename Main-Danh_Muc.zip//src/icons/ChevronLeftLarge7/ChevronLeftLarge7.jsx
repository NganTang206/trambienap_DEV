/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const ChevronLeftLarge7 = ({ className }) => {
  return (
    <svg
      className={`chevron-left-large-7 ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect className="rect" fill="white" fillOpacity="0.01" height="24" width="24" />
      <path
        className="path"
        clipRule="evenodd"
        d="M9.005 10.995L13.598 6.402C13.6896 6.30855 13.7988 6.23417 13.9193 6.18318C14.0398 6.1322 14.1692 6.1056 14.3001 6.10494C14.4309 6.10428 14.5606 6.12957 14.6816 6.17933C14.8026 6.2291 14.9126 6.30237 15.0051 6.39489C15.0976 6.48742 15.1709 6.59737 15.2207 6.71838C15.2704 6.8394 15.2957 6.96908 15.2951 7.09993C15.2944 7.23078 15.2678 7.3602 15.2168 7.4807C15.1658 7.60121 15.0915 7.71041 14.998 7.802L11.098 11.702L14.998 15.602C15.1806 15.7883 15.2822 16.0391 15.2809 16.2999C15.2796 16.5608 15.1754 16.8105 14.991 16.995C14.8065 17.1794 14.5568 17.2836 14.2959 17.2849C14.0351 17.2862 13.7843 17.1846 13.598 17.002L9.005 12.41C8.81753 12.2225 8.71221 11.9682 8.71221 11.703C8.71221 11.4378 8.81753 11.1835 9.005 10.996V10.995Z"
        fill="#42526E"
        fillRule="evenodd"
      />
    </svg>
  );
};
