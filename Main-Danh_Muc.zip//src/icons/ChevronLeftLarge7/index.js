export { ChevronLeftLarge7 } from "./ChevronLeftLarge7";
