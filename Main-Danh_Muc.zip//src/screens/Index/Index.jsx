import React from "react";
import { Body } from "../../components/Body";
import { Header } from "../../components/Header";
import { NavContentSidebar } from "../../components/NavContentSidebar";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="page-wrapper">
        <div className="page">
          <NavContentSidebar
            className="nav-content-sidebar-instance"
            itemBulkPropertyHeThong="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk-1@2x.png"
            itemProperty1="idm-selected"
            itemPropertyHtClassName="nav-content-sidebar-2"
            logoEvnhcmcIcon="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af8262ded9bf6dcc605ac2/img/logo-evnhcmc-icon-5@2x.png"
            property1="default-close"
          />
          <div className="page-container">
            <Header
              buttonSubtleLinearPropertyChNhSA="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-39@2x.png"
              className="header-instance"
            />
            <div className="frame-2">
              <Body className="body-instance" paginationLengthLongClassName="body-3" tableMaskClassName="body-2" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
