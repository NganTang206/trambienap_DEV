import React from "react";
import { Login } from "../../components/Login";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="overlap-group-wrapper">
        <div className="overlap-group-2">
          <img
            className="lines"
            alt="Lines"
            src="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/lines-1.png"
          />
          <img
            className="img"
            alt="Lines"
            src="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/lines-2.png"
          />
          <img
            className="bg"
            alt="Bg"
            src="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/bg.svg"
          />
          <p className="t-NG-c-NG-TY-i-n-l-c">
            <span className="span">
              TỔNG CÔNG TY ĐIỆN LỰC THÀNH PHỐ HỒ CHÍ MINH
              <br />
              Địa chỉ: 35 Tôn Đức Thắng - Phường Bến Nghé - Quận 1 - TP.Hồ Chí Minh. Website: www.evnhcmc.vn
              <br />
              Thiết kế và phát triển bởi{" "}
            </span>
            <span className="text-wrapper-4">EVNHCMCIT</span>
            <span className="span">
              . Bản quyền thuộc về Tập đoàn Điện lực Việt Nam.
              <br />
            </span>
            <span className="text-wrapper-5">Version 1.0</span>
          </p>
          <Login
            buttonPrimaryLinearPropertyLogin="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/linear-62@2x.png"
            className="login-instance"
            logoEvnhcmc="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/logo-evnhcmc-2@2x.png"
            logoEvnhcmcClassName="login-2"
          />
        </div>
      </div>
    </div>
  );
};
