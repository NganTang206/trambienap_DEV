/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { ButtonPrimary } from "../ButtonPrimary";
import { Select } from "../Select";
import "./style.css";

export const Login = ({
  className,
  logoEvnhcmcClassName,
  logoEvnhcmc = "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65ad62ba234254cc5d203ffa/img/line-1--stroke--540@2x.png",
  buttonPrimaryLinearPropertyLogin = "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65ad62ba234254cc5d203ffa/img/line-1--stroke--540@2x.png",
}) => {
  return (
    <div className={`login ${className}`}>
      <div className="frame">
        <img className={`logo-evnhcmc ${logoEvnhcmcClassName}`} alt="Logo evnhcmc" src={logoEvnhcmc} />
        <div className="div">
          <div className="text-wrapper-2">Đăng nhập</div>
          <div className="frame-2">
            <div className="input">
              <div className="text-wrapper-3">Tên đăng nhập</div>
              <Select
                className="select-instance"
                default1
                invalid={false}
                placeholderClassName="design-component-instance-node"
                placeholderClassNameOverride="select-2"
                stateProp="default"
                text="Username"
              />
            </div>
            <div className="input">
              <div className="text-wrapper-3">Mật khẩu</div>
              <Select
                className="select-instance"
                default1
                invalid={false}
                placeholderClassName="design-component-instance-node"
                placeholderClassNameOverride="select-2"
                stateProp="default"
                text="Password"
              />
            </div>
          </div>
          <ButtonPrimary
            className="button-primary-2"
            divClassName="button-primary-3"
            icon="before"
            linearProperty1="login"
            linearPropertyChNhSAClassName="button-primary-instance"
            linearPropertyLogin={buttonPrimaryLinearPropertyLogin}
            loading={false}
            spacing="default"
            stateProp="default"
            text="Đăng nhập"
          />
        </div>
      </div>
    </div>
  );
};

Login.propTypes = {
  logoEvnhcmc: PropTypes.string,
  buttonPrimaryLinearPropertyLogin: PropTypes.string,
};
