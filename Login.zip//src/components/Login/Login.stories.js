import { Login } from ".";

export default {
  title: "Components/Login",
  component: Login,
};

export const Default = {
  args: {
    className: {},
    logoEvnhcmcClassName: {},
    logoEvnhcmc:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65ad62ba234254cc5d203ffa/img/line-1--stroke--540@2x.png",
    buttonPrimaryLinearPropertyLogin:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65ad62ba234254cc5d203ffa/img/line-1--stroke--540@2x.png",
  },
};
