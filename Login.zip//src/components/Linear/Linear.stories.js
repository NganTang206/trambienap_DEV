import { Linear } from ".";

export default {
  title: "Components/Linear",
  component: Linear,
  argTypes: {
    property1: {
      options: ["add", "login", "security-safe", "more", "ch-nh-s-a", "loading", "search"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "add",
    className: {},
    propertyLogin:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/property-1--login@2x.png",
    propertyChNhSA:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/linear-50@2x.png",
    propertyMore:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/linear-31@2x.png",
    propertyLoading:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/property-1-loading@2x.png",
  },
};
