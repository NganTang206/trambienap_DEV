/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { useReducer } from "react";
import { Item } from "../Item";
import { ItemWrapper } from "../ItemWrapper";
import "./style.css";

export const NavContentSidebar = ({
  showLayers = true,
  property1,
  className,
  itemProperty1 = "iht-default",
  itemBulkPropertyHeThong = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk@2x.png",
  itemPropertyHtClassName,
}) => {
  const [state, dispatch] = useReducer(reducer, {
    property1: property1 || "default-open",
  });

  return (
    <div
      className={`nav-content-sidebar property-1-0-${state.property1} ${className}`}
      onMouseLeave={() => {
        dispatch("mouse_leave");
      }}
      onMouseEnter={() => {
        dispatch("mouse_enter");
      }}
    >
      <div className="content-sidebar">
        {["default-close", "default-open"].includes(state.property1) && (
          <>
            <img
              className="logo-evnhcmc"
              alt="Logo evnhcmc"
              src={
                state.property1 === "default-close"
                  ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/logo-evnhcmc-icon@2x.png"
                  : "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/logo-evnhcmc-1@2x.png"
              }
            />
            <div className="menu">
              <Item
                bulkPropertyHeThong={itemBulkPropertyHeThong}
                property1={itemProperty1}
                propertyHtClassName={itemPropertyHtClassName}
              />
              <Item
                property1={state.property1 === "default-close" ? "idm-default" : "DM-default"}
                propertyHtClassName="item-instance"
              />
            </div>
          </>
        )}

        {state.property1 === "change-pass" && (
          <>
            <div className="group-wrapper">
              <img
                className="group"
                alt="Group"
                src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/group.png"
              />
            </div>
            <div className="menu-2">
              <div className="item-2">
                <div className="item-3">
                  <img
                    className="bulk-2"
                    alt="Bulk"
                    src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk@2x.png"
                  />
                  <div className="text-wrapper-3">Hệ Thống</div>
                  <img
                    className="chevron-down-3"
                    alt="Chevron down"
                    src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-down@2x.png"
                  />
                </div>
                <Item property1="change-pass" propertyHtClassName="item-instance" />
              </div>
              <Item property1="DM-default" propertyHtClassName="item-instance" />
            </div>
          </>
        )}

        <div className="line-device">
          <div className="div-wrapper">
            <div className="text-wrapper-4">My Library</div>
          </div>
        </div>
        {state.property1 === "change-pass" && (
          <ItemWrapper
            avatarSilhouettePresence="online"
            avatarSilhouettePresenceClassName="item-4"
            className="instance-node"
            username="Ngan2TD\\hcmpc.com.vn"
          />
        )}

        {["default-close", "default-open"].includes(state.property1) && (
          <ItemWrapper
            avatarSilhouettePresence="online"
            avatarSilhouettePresenceClassName="item-4"
            className={`${state.property1 === "default-close" ? "class" : "instance-node"}`}
            showUsername={state.property1 === "default-close" ? false : undefined}
            username={state.property1 === "default-open" ? "Ngan2TD\\hcmpc.com.vn" : undefined}
          />
        )}
      </div>
    </div>
  );
};

function reducer(state, action) {
  switch (action) {
    case "mouse_leave":
      return {
        ...state,
        property1: "default-close",
      };

    case "mouse_enter":
      return {
        ...state,
        property1: "default-open",
      };
  }

  return state;
}

NavContentSidebar.propTypes = {
  showLayers: PropTypes.bool,
  property1: PropTypes.oneOf(["change-pass", "default-close", "default-open"]),
  itemProperty1: PropTypes.string,
  itemBulkPropertyHeThong: PropTypes.string,
};
