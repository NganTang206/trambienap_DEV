import { Linear } from ".";

export default {
  title: "Components/Linear",
  component: Linear,
  argTypes: {
    property1: {
      options: ["add", "login", "security-safe", "more", "ch-nh-s-a", "loading", "search"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "add",
    className: {},
    propertyChNhSA:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-53@2x.png",
    propertyMore:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-31@2x.png",
    propertyLoading:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-loading@2x.png",
  },
};
