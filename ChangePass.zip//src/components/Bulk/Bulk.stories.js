import { Bulk } from ".";

export default {
  title: "Components/Bulk",
  component: Bulk,
  argTypes: {
    property1: {
      options: ["danh-muc", "he-thong"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "danh-muc",
    className: {},
    propertyHeThong:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-he-thong@2x.png",
    propertyDanhMuc:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-danh-muc@2x.png",
  },
};
