import { Select } from ".";

export default {
  title: "Components/Select",
  component: Select,
  argTypes: {
    stateProp: {
      options: ["default", "hover", "focus", "disabled"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    default1: true,
    invalid: true,
    stateProp: "default",
    className: {},
    placeholderClassName: {},
    placeholderClassNameOverride: {},
    text: "Username",
  },
};
