/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { useReducer } from "react";
import "./style.css";

export const Select = ({
  default1,
  invalid,
  stateProp,
  className,
  placeholderClassName,
  placeholderClassNameOverride,
  text = "Username",
}) => {
  const [state, dispatch] = useReducer(reducer, {
    default2: default1 || true,
    invalid: invalid || false,
    state: stateProp || "default",
  });

  return (
    <div
      className={`select ${state.state} invalid-${state.invalid} default-${state.default2} ${className}`}
      onMouseEnter={() => {
        dispatch("mouse_enter");
      }}
      onMouseLeave={() => {
        dispatch("mouse_leave");
      }}
      onClick={() => {
        dispatch("click");
      }}
    >
      {!state.invalid && (
        <div className={`placeholder-3 ${placeholderClassName}`}>
          {!state.default2 && <>{text}</>}

          {state.default2 && <div className={`placeholder ${placeholderClassNameOverride}`}>{text}</div>}
        </div>
      )}

      {state.invalid && (
        <>
          <div className="error-text">
            <img
              className="error"
              alt="Error"
              src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af8262ded9bf6dcc605ac2/img/error@2x.png"
            />
            <p className="text">Help or instruction text goes here</p>
          </div>
          <div className="overlap-group">
            <div className="placeholder-2">{text}</div>
          </div>
        </>
      )}
    </div>
  );
};

function reducer(state, action) {
  if (state.default2 === false && state.invalid === false && state.state === "hover") {
    switch (action) {
      case "click":
        return {
          default2: false,
          invalid: false,
          state: "focus",
        };

      case "mouse_leave":
        return {
          default2: true,
          invalid: false,
          state: "default",
        };
    }
  }

  if (state.default2 === true && state.invalid === false && state.state === "default") {
    switch (action) {
      case "mouse_enter":
        return {
          default2: false,
          invalid: false,
          state: "hover",
        };
    }
  }

  return state;
}

Select.propTypes = {
  default1: PropTypes.bool,
  invalid: PropTypes.bool,
  stateProp: PropTypes.oneOf(["default", "hover", "focus", "disabled"]),
  text: PropTypes.string,
};
