export { AvatarSilhouette } from "./AvatarSilhouette";
