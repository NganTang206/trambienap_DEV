import React from "react";
import { ButtonBorder } from "../../components/ButtonBorder";
import { ButtonPrimary } from "../../components/ButtonPrimary";
import { NavContentSidebar } from "../../components/NavContentSidebar";
import { Select } from "../../components/Select";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="page-wrapper">
        <div className="page">
          <NavContentSidebar
            className="nav-content-sidebar-instance"
            itemBulkPropertyHeThong="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk-1@2x.png"
            itemProperty1="iht-selected"
            itemPropertyHtClassName="design-component-instance-node"
            property1="default-close"
          />
          <div className="page-container">
            <header className="header">
              <div className="breadcrumbs">
                <div className="breadcrumb">
                  <div className="text-wrapper-5">Trang chủ</div>
                </div>
                <div className="breadcrumb">
                  <img
                    className="vector"
                    alt="Vector"
                    src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/vector@2x.png"
                  />
                  <div className="text-wrapper-5">Hệ Thống</div>
                </div>
                <div className="breadcrumb">
                  <img
                    className="vector"
                    alt="Vector"
                    src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/vector@2x.png"
                  />
                  <div className="text-wrapper-5">Thay đổi mật khẩu</div>
                </div>
              </div>
              <div className="main-content">
                <div className="text-wrapper-6">Thay đổi mật khẩu</div>
              </div>
            </header>
            <div className="change-pass-2">
              <div className="input">
                <div className="input-2">
                  <div className="text-wrapper-7">Mật khẩu cũ</div>
                  <Select
                    className="select-instance"
                    default1
                    invalid={false}
                    placeholderClassName="select-2"
                    placeholderClassNameOverride="select-3"
                    stateProp="default"
                  />
                </div>
                <div className="input-2">
                  <div className="text-wrapper-7">Mật khẩu mới</div>
                  <Select
                    className="select-instance"
                    default1
                    invalid={false}
                    placeholderClassName="select-2"
                    placeholderClassNameOverride="select-3"
                    stateProp="default"
                    text="Password"
                  />
                </div>
                <div className="input-2">
                  <p className="text-wrapper-7">Xác nhận mật khẩu mới</p>
                  <Select
                    className="select-instance"
                    default1
                    invalid={false}
                    placeholderClassName="select-2"
                    placeholderClassNameOverride="select-3"
                    stateProp="default"
                    text="Password"
                  />
                </div>
              </div>
              <ButtonPrimary
                className="button-primary-instance"
                icon="none"
                loading={false}
                spacing="default"
                stateProp="default"
                text="Xác nhận mật khẩu"
              />
              <ButtonBorder
                className="button-border-instance"
                icon="none"
                loading={false}
                spacing="default"
                stateProp="default"
                text="Huỷ thay đổi"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
