/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { ButtonPrimary } from "../ButtonPrimary";
import { ButtonSubtle } from "../ButtonSubtle";
import { FilterBar } from "../FilterBar";
import "./style.css";

export const Header = ({
  className,
  buttonPrimaryLinearPropertyAdd = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-38@2x.png",
  buttonSubtleLinearPropertyChNhSA = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear@2x.png",
}) => {
  return (
    <div className={`header ${className}`}>
      <div className="breadcrumbs">
        <div className="breadcrumb">
          <div className="text-wrapper-7">Trang chủ</div>
        </div>
        <div className="breadcrumb">
          <img
            className="vector"
            alt="Vector"
            src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/vector@2x.png"
          />
          <div className="text-wrapper-7">Danh mục</div>
        </div>
        <div className="breadcrumb">
          <img
            className="vector"
            alt="Vector"
            src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/vector@2x.png"
          />
          <p className="text-wrapper-7">Danh sách điểm đo ảo</p>
        </div>
      </div>
      <div className="main-content">
        <p className="p">Danh sách điểm đo ảo</p>
      </div>
      <div className="filter-bar-2">
        <div className="filter-bar-wrapper">
          <FilterBar
            className="filter-bar-instance"
            linearPropertyChNhSAClassName="filter-bar-5"
            property1="default"
            textClassName="filter-bar-4"
            textFieldClassName="design-component-instance-node"
            textFieldTextClassName="filter-bar-3"
          />
        </div>
        <button className="button">
          <ButtonPrimary
            className="design-component-instance-node-2"
            icon="before"
            linearProperty1="add"
            linearPropertyAdd={buttonPrimaryLinearPropertyAdd}
            loading={false}
            spacing="default"
            stateProp="default"
            text="Thêm"
          />
          <ButtonSubtle
            className="design-component-instance-node-2"
            icon="before"
            linearPropertyChNhSA={buttonSubtleLinearPropertyChNhSA}
            loading={false}
            spacing="default"
            stateProp="default"
            text="Chỉnh sửa"
          />
          <ButtonSubtle
            className="button-subtle-instance"
            icon="only"
            loading={false}
            spacing="default"
            stateProp="default"
          />
        </button>
      </div>
    </div>
  );
};

Header.propTypes = {
  buttonPrimaryLinearPropertyAdd: PropTypes.string,
  buttonSubtleLinearPropertyChNhSA: PropTypes.string,
};
