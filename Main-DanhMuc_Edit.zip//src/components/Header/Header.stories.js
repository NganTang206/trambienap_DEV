import { Header } from ".";

export default {
  title: "Components/Header",
  component: Header,
};

export const Default = {
  args: {
    className: {},
    buttonPrimaryLinearPropertyAdd:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-38@2x.png",
    buttonSubtleLinearPropertyChNhSA:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear@2x.png",
  },
};
