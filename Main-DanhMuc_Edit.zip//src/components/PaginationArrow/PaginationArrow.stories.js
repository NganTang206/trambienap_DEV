import { PaginationArrow } from ".";

export default {
  title: "Components/PaginationArrow",
  component: PaginationArrow,
  argTypes: {
    state: {
      options: ["disabled", "active", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    state: "disabled",
    className: {},
  },
};
