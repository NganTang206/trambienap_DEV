/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const Linear = ({
  property1,
  className,
  propertySearch = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-search@2x.png",
  propertyAdd = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-add@2x.png",
  propertyChNhSA = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-53@2x.png",
  propertyMore = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-31@2x.png",
  propertyLoading = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-loading@2x.png",
}) => {
  return (
    <img
      className={`linear ${property1} ${className}`}
      alt="Property ch nh s a"
      src={
        property1 === "add"
          ? propertyAdd
          : property1 === "more"
          ? propertyMore
          : property1 === "search"
          ? propertySearch
          : property1 === "loading"
          ? propertyLoading
          : property1 === "login"
          ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1--login@2x.png"
          : property1 === "security-safe"
          ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-security-safe@2x.png"
          : propertyChNhSA
      }
    />
  );
};

Linear.propTypes = {
  property1: PropTypes.oneOf(["add", "login", "security-safe", "more", "ch-nh-s-a", "loading", "search"]),
  propertySearch: PropTypes.string,
  propertyAdd: PropTypes.string,
  propertyChNhSA: PropTypes.string,
  propertyMore: PropTypes.string,
  propertyLoading: PropTypes.string,
};
