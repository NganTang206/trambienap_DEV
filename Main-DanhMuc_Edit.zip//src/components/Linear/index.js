export { Linear } from "./Linear";
