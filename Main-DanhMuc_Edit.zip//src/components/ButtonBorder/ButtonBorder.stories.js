import { ButtonBorder } from ".";

export default {
  title: "Components/ButtonBorder",
  component: ButtonBorder,
  argTypes: {
    icon: {
      options: ["none", "only", "before"],
      control: { type: "select" },
    },
    stateProp: {
      options: ["hover", "active", "default"],
      control: { type: "select" },
    },
    spacing: {
      options: ["compact", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    icon: "none",
    stateProp: "hover",
    spacing: "compact",
    loading: true,
    className: {},
    text: "Label",
  },
};
