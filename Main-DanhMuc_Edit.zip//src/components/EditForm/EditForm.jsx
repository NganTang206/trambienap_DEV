/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { ButtonBorder } from "../ButtonBorder";
import { ButtonPrimary } from "../ButtonPrimary";
import { Select } from "../Select";
import "./style.css";

export const EditForm = ({ property1, className, selectStateProp = "default", selectPlaceholderClassName }) => {
  return (
    <div className={`edit-form ${property1} ${className}`}>
      <div className="frame-2">
        <div className="text-wrapper-9">Chỉ danh</div>
        <Select
          className="select-instance"
          compact={false}
          dropdownMenuClassName="select-2"
          invalid={false}
          loading={false}
          opened={false}
          selectFieldFocusClassName="select-3"
          stateProp="default"
          subtle={false}
          text={property1 === "form-edit" ? "431" : "--Chọn--"}
          validated={false}
        />
      </div>
      <div className="frame-3">
        <div className="text-wrapper-9">Tên trạm</div>
        <Select
          className="select-instance"
          compact={false}
          dropdownMenuClassName={`${property1 === "form-add" && "select-2"}`}
          hasDropdownMenu={property1 === "form-edit" ? false : undefined}
          invalid={false}
          loading={false}
          opened={false}
          selectFieldFocusClassName={`${property1 === "form-edit" ? "select-4" : "select-3"}`}
          stateProp="default"
          subtle={false}
          text={property1 === "form-edit" ? "Trạm Bà Quẹo" : "--Chọn--"}
          validated={false}
        />
      </div>
      <div className="frame-4">
        <div className="text-wrapper-9">Điểm Đo Ảo</div>
        <Select
          className="select-instance"
          compact={false}
          hasDropdownMenu={false}
          invalid={false}
          loading={false}
          opened={false}
          placeholderClassName={selectPlaceholderClassName}
          selectFieldFocusClassName="select-4"
          stateProp={selectStateProp}
          subtle={false}
          text="T1"
          validated={false}
        />
      </div>
      <ButtonPrimary
        className={`${property1 === "form-edit" ? "class-8" : "class-9"}`}
        icon="none"
        loading={false}
        spacing="default"
        stateProp="default"
        text={property1 === "form-edit" ? "Cập nhật" : "Lưu"}
      />
      <ButtonBorder
        className={`${property1 === "form-edit" ? "class-10" : "class-11"}`}
        icon="none"
        loading={false}
        spacing="default"
        stateProp="default"
        text="Huỷ"
      />
    </div>
  );
};

EditForm.propTypes = {
  property1: PropTypes.oneOf(["form-add", "form-edit"]),
  selectStateProp: PropTypes.string,
};
