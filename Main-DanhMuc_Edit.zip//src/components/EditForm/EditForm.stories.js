import { EditForm } from ".";

export default {
  title: "Components/EditForm",
  component: EditForm,
  argTypes: {
    property1: {
      options: ["form-add", "form-edit"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "form-add",
    className: {},
    selectStateProp: "default",
    selectPlaceholderClassName: {},
  },
};
