/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { useReducer } from "react";
import { Linear } from "../Linear";
import "./style.css";

export const ButtonPrimary = ({
  icon,
  stateProp,
  spacing,
  loading,
  className,
  linearPropertyAdd,
  linearProperty1 = "ch-nh-s-a",
  text = "Label",
}) => {
  const [state, dispatch] = useReducer(reducer, {
    icon: icon || "none",
    state: stateProp || "default",
    spacing: spacing || "default",
    loading: loading || false,
  });

  return (
    <div
      className={`button-primary state-${state.state} ${state.icon} spacing-${state.spacing} loading-${state.loading} ${className}`}
      onMouseLeave={() => {
        dispatch("mouse_leave");
      }}
      onMouseEnter={() => {
        dispatch("mouse_enter");
      }}
    >
      {state.icon === "before" && (
        <Linear
          className="linear-3"
          property1={linearProperty1}
          propertyAdd={linearPropertyAdd}
          propertyChNhSA="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-14@2x.png"
        />
      )}

      {(state.icon === "before" || (!state.loading && state.icon === "none")) && <div className="label">{text}</div>}

      {(state.loading || state.icon === "only") && (
        <Linear
          className={`${
            !state.loading ? "linear-3" : state.spacing === "compact" && state.icon === "none" ? "class-2" : "class-3"
          }`}
          property1={state.icon === "none" ? "loading" : "more"}
          propertyLoading={
            state.loading && state.spacing === "default"
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-23@2x.png"
              : state.spacing === "compact" && state.icon === "none"
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-27@2x.png"
              : undefined
          }
          propertyMore={
            !state.loading
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-17@2x.png"
              : undefined
          }
        />
      )}
    </div>
  );
};

function reducer(state, action) {
  switch (action) {
    case "mouse_enter":
      return {
        ...state,
        state: "hover",
      };

    case "mouse_leave":
      return {
        ...state,
        state: "default",
      };
  }

  return state;
}

ButtonPrimary.propTypes = {
  icon: PropTypes.oneOf(["none", "only", "before"]),
  stateProp: PropTypes.oneOf(["hover", "active", "default"]),
  spacing: PropTypes.oneOf(["compact", "default"]),
  loading: PropTypes.bool,
  linearPropertyAdd: PropTypes.string,
  linearProperty1: PropTypes.string,
  text: PropTypes.string,
};
