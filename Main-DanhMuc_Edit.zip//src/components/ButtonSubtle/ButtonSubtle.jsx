/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { useReducer } from "react";
import { Linear } from "../Linear";
import "./style.css";

export const ButtonSubtle = ({
  icon,
  stateProp,
  spacing,
  loading,
  className,
  linearPropertyChNhSA = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear@2x.png",
  text = "Label",
}) => {
  const [state, dispatch] = useReducer(reducer, {
    icon: icon || "none",
    state: stateProp || "default",
    spacing: spacing || "default",
    loading: loading || false,
  });

  return (
    <div
      className={`button-subtle state-0-${state.state} icon-${state.icon} spacing-0-${state.spacing} loading-0-${state.loading} ${className}`}
      onMouseLeave={() => {
        dispatch("mouse_leave");
      }}
      onMouseEnter={() => {
        dispatch("mouse_enter");
      }}
    >
      {state.icon === "before" && (
        <Linear className="linear-4" property1="ch-nh-s-a" propertyChNhSA={linearPropertyChNhSA} />
      )}

      {(state.icon === "before" || (!state.loading && state.icon === "none")) && <div className="label-2">{text}</div>}

      {(state.loading || state.icon === "only") && (
        <Linear
          className={`${
            !state.loading ? "linear-4" : state.spacing === "compact" && state.icon === "none" ? "class-4" : "class-5"
          }`}
          property1={state.icon === "none" ? "loading" : "more"}
          propertyLoading={
            state.loading && state.spacing === "default"
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-9@2x.png"
              : state.spacing === "compact" && state.icon === "none"
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-13@2x.png"
              : undefined
          }
          propertyMore={
            state.state === "active"
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-31@2x.png"
              : "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-3@2x.png"
          }
        />
      )}
    </div>
  );
};

function reducer(state, action) {
  switch (action) {
    case "mouse_enter":
      return {
        ...state,
        state: "hover",
      };

    case "mouse_leave":
      return {
        ...state,
        state: "default",
      };
  }

  return state;
}

ButtonSubtle.propTypes = {
  icon: PropTypes.oneOf(["none", "only", "before"]),
  stateProp: PropTypes.oneOf(["hover", "active", "default"]),
  spacing: PropTypes.oneOf(["compact", "default"]),
  loading: PropTypes.bool,
  linearPropertyChNhSA: PropTypes.string,
  text: PropTypes.string,
};
