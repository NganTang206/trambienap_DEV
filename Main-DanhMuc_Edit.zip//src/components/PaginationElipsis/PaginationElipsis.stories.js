import { PaginationElipsis } from ".";

export default {
  title: "Components/PaginationElipsis",
  component: PaginationElipsis,
};

export const Default = {
  args: {
    className: {},
    paginationElipsis:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/pagination-elipsis-3@2x.png",
  },
};
