/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { useReducer } from "react";
import { Linear } from "../Linear";
import "./style.css";

export const Select = ({
  opened,
  compact,
  subtle,
  invalid,
  validated,
  loading,
  stateProp,
  className,
  selectFieldFocusClassName,
  text = "--Chọn--",
  dropdownMenuClassName,
  hasDropdownMenu = true,
  placeholderClassName,
}) => {
  const [state, dispatch] = useReducer(reducer, {
    opened: opened || false,
    compact: compact || false,
    subtle: subtle || false,
    invalid: invalid || false,
    validated: validated || false,
    loading: loading || false,
    state: stateProp || "default",
  });

  return (
    <div
      className={`select state-3-${state.state} loading-1-${state.loading} ${className}`}
      onMouseEnter={() => {
        dispatch("mouse_enter");
      }}
      onMouseLeave={() => {
        dispatch("mouse_leave");
      }}
    >
      {["default", "focus", "selected"].includes(state.state) && (
        <div className={`select-field-focus ${selectFieldFocusClassName}`}>
          {state.state === "focus" && (
            <>
              <img
                className="img-2"
                alt="Chevron down"
                src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-down@2x.png"
              />
              <div className="placeholder">{text}</div>
            </>
          )}

          {!state.opened && <>{text}</>}

          {state.state === "selected" && <>Option</>}
        </div>
      )}

      {state.state === "disabled" && <div className={`placeholder-2 ${placeholderClassName}`}>{text}</div>}

      {state.state === "hover" && (
        <img
          className={`img-2 ${selectFieldFocusClassName}`}
          alt="Icon after"
          src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-down@2x.png"
        />
      )}

      {["default", "focus", "hover", "selected"].includes(state.state) && (
        <>
          <>
            {hasDropdownMenu && (
              <>
                <>
                  {["focus", "hover"].includes(state.state) && (
                    <div
                      className={`dropdown-menu-2 ${state.state} opened-${state.opened} loading-3-${state.loading} ${dropdownMenuClassName}`}
                    >
                      {!state.loading && state.opened && (
                        <>
                          <div className="dropdown-item-2">
                            <div className="text-wrapper-8">Option</div>
                          </div>
                          <div className="dropdown-item-2">
                            <div className="text-wrapper-8">Option</div>
                          </div>
                          <div className="dropdown-item-2">
                            <div className="text-wrapper-8">Option</div>
                          </div>
                          <div className="dropdown-item-2">
                            <div className="text-wrapper-8">Option</div>
                          </div>
                          <div className="dropdown-item-2">
                            <div className="text-wrapper-8">Option</div>
                          </div>
                          <div className="dropdown-item-2">
                            <div className="text-wrapper-8">Option</div>
                          </div>
                          <div className="dropdown-item-2">
                            <div className="text-wrapper-8">Option</div>
                          </div>
                          <div className="dropdown-item-2">
                            <div className="text-wrapper-8">Option</div>
                          </div>
                        </>
                      )}

                      {state.loading && (
                        <Linear
                          className="linear-5"
                          property1="loading"
                          propertyLoading="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-36@2x.png"
                        />
                      )}

                      {!state.opened && <>{text}</>}
                    </div>
                  )}

                  {["default", "selected"].includes(state.state) && (
                    <img
                      className={`img-2 ${dropdownMenuClassName}`}
                      alt="Chevron down"
                      src={
                        state.opened
                          ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-down-6@2x.png"
                          : "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-down@2x.png"
                      }
                    />
                  )}
                </>
              </>
            )}
          </>
        </>
      )}
    </div>
  );
};

function reducer(state, action) {
  switch (action) {
    case "mouse_enter":
      return {
        ...state,
        state: "hover",
      };

    case "mouse_leave":
      return {
        ...state,
        state: "default",
      };
  }

  return state;
}

Select.propTypes = {
  opened: PropTypes.bool,
  compact: PropTypes.bool,
  subtle: PropTypes.bool,
  invalid: PropTypes.bool,
  validated: PropTypes.bool,
  loading: PropTypes.bool,
  stateProp: PropTypes.oneOf(["default", "selected", "focus", "hover", "disabled"]),
  text: PropTypes.string,
  hasDropdownMenu: PropTypes.bool,
};
