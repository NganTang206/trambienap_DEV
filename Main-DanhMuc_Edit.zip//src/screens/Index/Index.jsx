import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { Body } from "../../components/Body";
import { EditForm } from "../../components/EditForm";
import { Header } from "../../components/Header";
import { NavContentSidebar } from "../../components/NavContentSidebar";
import "./style.css";

export const Index = () => {
  const screenWidth = useWindowWidth();

  return (
    <div className="index">
      <div className="page-wrapper">
        <div className="page">
          <NavContentSidebar
            className="instance-node-2"
            itemBulkPropertyHeThong="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk-1@2x.png"
            itemProperty1="idm-selected"
            itemPropertyHtClassName="nav-content-sidebar-instance"
            property1="default-close"
          />
          <div className="page-container">
            <Header
              buttonPrimaryLinearPropertyAdd={
                screenWidth < 1920
                  ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-62@2x.png"
                  : screenWidth >= 1920
                  ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-38@2x.png"
                  : undefined
              }
              buttonSubtleLinearPropertyChNhSA={
                screenWidth < 1920
                  ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-63@2x.png"
                  : screenWidth >= 1920
                  ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-39@2x.png"
                  : undefined
              }
              className="header-instance"
            />
            <div className="frame-5">
              <Body className="body-instance" />
              <EditForm
                className="instance-node-2"
                property1={screenWidth < 1920 ? "form-edit" : screenWidth >= 1920 ? "form-add" : undefined}
                selectPlaceholderClassName="edit-form-instance"
                selectStateProp="disabled"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
