/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const EmtyState = ({
  className,
  noResults = "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af6f92511fa794f099964c/img/no-results.svg",
}) => {
  return (
    <div className={`emty-state ${className}`}>
      <img className="no-results" alt="No results" src={noResults} />
      <div className="search-not-found">Tìm kiếm trống</div>
    </div>
  );
};

EmtyState.propTypes = {
  noResults: PropTypes.string,
};
