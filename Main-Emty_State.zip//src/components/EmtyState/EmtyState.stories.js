import { EmtyState } from ".";

export default {
  title: "Components/EmtyState",
  component: EmtyState,
};

export const Default = {
  args: {
    className: {},
    noResults:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af6f92511fa794f099964c/img/no-results.svg",
  },
};
