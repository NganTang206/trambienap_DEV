/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { useReducer } from "react";
import { Linear } from "../Linear";
import "./style.css";

export const FilterBar = ({
  property1,
  className,
  textFieldClassName,
  textFieldTextClassName,
  textClassName,
  linearPropertyChNhSAClassName,
}) => {
  const [state, dispatch] = useReducer(reducer, {
    property1: property1 || "default",
  });

  return (
    <div
      className={`filter-bar ${state.property1} ${className}`}
      onMouseLeave={() => {
        dispatch("mouse_leave");
      }}
      onMouseEnter={() => {
        dispatch("mouse_enter");
      }}
    >
      {["default", "variant-4"].includes(state.property1) && (
        <div className={`text-field ${textFieldClassName}`}>
          <div className={`text-field-text ${textFieldTextClassName}`}>
            <div className={`text ${textClassName}`}>Tìm kiếm trạm</div>
          </div>
          <Linear
            className={linearPropertyChNhSAClassName}
            property1="search"
            propertySearch="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/linear-37@2x.png"
          />
        </div>
      )}

      {["dropdown", "selected"].includes(state.property1) && (
        <>
          <div className="text-field-wrapper">
            <div className="text-field-2">
              <div className="text-field-text">
                <div className="text-2">Trạm Bà Quẹo...</div>
              </div>
              <Linear
                className="linear-2"
                property1="search"
                propertySearch="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/linear-42@2x.png"
              />
            </div>
          </div>
          <div className="dropdown-menu">
            <div className="dropdown-item">
              <div className="frame">
                <div className="text-wrapper-5">TBTID</div>
                <div className="text-wrapper-6">Trạm Bà Quẹo 1</div>
              </div>
            </div>
            <div className="dropdown-item">
              <div className="frame">
                <div className="text-wrapper-5">TBTID</div>
                <div className="text-wrapper-6">Trạm Bà Quẹo 2</div>
              </div>
            </div>
            <div className="frame-wrapper">
              <div className="frame">
                <div className="text-wrapper-5">TBTID</div>
                <div className="text-wrapper-6">Trạm Bà Quẹo 3</div>
              </div>
            </div>
            <div className="dropdown-item">
              <div className="frame">
                <div className="text-wrapper-5">TBTID</div>
                <div className="text-wrapper-6">Trạm Bà Quẹo 4</div>
              </div>
            </div>
            <div className="dropdown-item">
              <div className="frame">
                <div className="text-wrapper-5">TBTID</div>
                <div className="text-wrapper-6">Trạm Bà Quẹo 5</div>
              </div>
            </div>
            <div className="dropdown-item">
              <div className="frame">
                <div className="text-wrapper-5">TBTID</div>
                <div className="text-wrapper-6">Trạm Bà Quẹo 6</div>
              </div>
            </div>
            <div className="dropdown-item">
              <div className="frame">
                <div className="text-wrapper-5">TBTID</div>
                <div className="text-wrapper-6">Trạm Bà Quẹo 7</div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

function reducer(state, action) {
  switch (action) {
    case "mouse_enter":
      return {
        ...state,
        property1: "variant-4",
      };

    case "mouse_leave":
      return {
        ...state,
        property1: "default",
      };
  }

  return state;
}

FilterBar.propTypes = {
  property1: PropTypes.oneOf(["variant-4", "dropdown", "selected", "default"]),
};
