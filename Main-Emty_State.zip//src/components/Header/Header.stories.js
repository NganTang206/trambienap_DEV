import { Header } from ".";

export default {
  title: "Components/Header",
  component: Header,
};

export const Default = {
  args: {
    className: {},
    hasBreadcrumb: true,
    hasDiv: true,
  },
};
