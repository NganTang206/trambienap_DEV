import { Item } from ".";

export default {
  title: "Components/Item",
  component: Item,
  argTypes: {
    property1: {
      options: [
        "iht-default",
        "HT-default",
        "idm-selected",
        "idn-default",
        "DN-selected",
        "DN-default",
        "HT-selected",
        "DM-default",
        "idm-default",
        "idn-selected",
        "pass",
        "DM-selected",
        "change-pass",
        "changepass-hover",
        "iht-selected",
      ],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "iht-default",
    propertyHtClassName: {},
    bulkPropertyHeThong:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/bulk-1@2x.png",
  },
};
