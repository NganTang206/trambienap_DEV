/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { AvatarSilhouette } from "../AvatarSilhouette";
import "./style.css";

export const ItemWrapper = ({
  showUsername = true,
  username = "Ngan2TD\\hcmpc.com.vn",
  className,
  avatarSilhouettePresence = "none",
  avatarSilhouettePresenceClassName,
}) => {
  return (
    <div className={`item-wrapper ${className}`}>
      <AvatarSilhouette
        className="avatar-silhouette-instance"
        presence={avatarSilhouettePresence}
        presenceClassName={avatarSilhouettePresenceClassName}
        size="forty-px"
        status="none"
      />
      {showUsername && <div className="danh-m-c">{username}</div>}
    </div>
  );
};

ItemWrapper.propTypes = {
  showUsername: PropTypes.bool,
  username: PropTypes.string,
  avatarSilhouettePresence: PropTypes.string,
};
