import { NavContentSidebar } from ".";

export default {
  title: "Components/NavContentSidebar",
  component: NavContentSidebar,
  argTypes: {
    property1: {
      options: ["change-pass", "default-close", "default-open"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    showLayers: true,
    property1: "change-pass",
    className: {},
    logoEvnhcmcIcon:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/logo-evnhcmc-icon@2x.png",
    itemBulkPropertyHeThong:
      "https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/bulk-1@2x.png",
  },
};
