import React from "react";
import { EmtyState } from "../../components/EmtyState";
import { Header } from "../../components/Header";
import { NavContentSidebar } from "../../components/NavContentSidebar";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="page-wrapper">
        <div className="page">
          <NavContentSidebar
            className="nav-content-sidebar-instance"
            itemBulkPropertyHeThong="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/bulk-17@2x.png"
            logoEvnhcmcIcon="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af36195f80386d9080d9dc/img/logo-evnhcmc-icon-2@2x.png"
            property1="default-close"
          />
          <div className="page-container">
            <Header className="header-instance" hasBreadcrumb={false} hasDiv={false} />
            <div className="body">
              <EmtyState
                className="emty-state-instance"
                noResults="https://cdn.animaapp.com/projects/65aa65562e39079ff6a0092d/releases/65af711ee662b52f95e4f528/img/no-results-1@2x.png"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
