import React from "react";
import { Body } from "../../components/Body";
import { EditForm } from "../../components/EditForm";
import { Header } from "../../components/Header";
import { NavContentSidebar } from "../../components/NavContentSidebar";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="page-wrapper">
        <div className="page">
          <NavContentSidebar
            className="design-component-instance-node-3"
            itemBulkPropertyHeThong="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk-1@2x.png"
            itemProperty1="idm-selected"
            itemPropertyHtClassName="nav-content-sidebar-instance"
            property1="default-close"
          />
          <div className="page-container">
            <Header
              buttonSubtleLinearPropertyChNhSA="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-39@2x.png"
              className="header-instance"
            />
            <div className="frame-5">
              <Body className="body-instance" />
              <EditForm
                className="design-component-instance-node-3"
                property1="form-add"
                selectPlaceholderClassName="edit-form-instance"
                selectStateProp="disabled"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
