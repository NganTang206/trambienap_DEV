/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const Bulk = ({
  property1,
  className,
  propertyHeThong = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-he-thong@2x.png",
  propertyDanhMuc = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/property-1-danh-muc@2x.png",
}) => {
  return (
    <img
      className={`bulk ${className}`}
      alt="Property he thong"
      src={property1 === "danh-muc" ? propertyDanhMuc : propertyHeThong}
    />
  );
};

Bulk.propTypes = {
  property1: PropTypes.oneOf(["danh-muc", "he-thong"]),
  propertyHeThong: PropTypes.string,
  propertyDanhMuc: PropTypes.string,
};
