import { NavContentSidebar } from ".";

export default {
  title: "Components/NavContentSidebar",
  component: NavContentSidebar,
  argTypes: {
    property1: {
      options: ["change-pass", "default-close", "default-open"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    showLayers: true,
    property1: "change-pass",
    className: {},
    itemBulkPropertyHeThong:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk@2x.png",
    itemPropertyHtClassName: {},
    itemProperty1: "idm-default",
  },
};
