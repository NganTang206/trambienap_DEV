import { ItemWrapper } from ".";

export default {
  title: "Components/ItemWrapper",
  component: ItemWrapper,
};

export const Default = {
  args: {
    showUsername: true,
    username: "Ngan2TD\\hcmpc.com.vn",
    className: {},
    avatarSilhouettePresence: "none",
    avatarSilhouettePresenceClassName: {},
  },
};
