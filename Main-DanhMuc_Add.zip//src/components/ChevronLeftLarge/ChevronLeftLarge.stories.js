import { ChevronLeftLarge } from ".";

export default {
  title: "Components/ChevronLeftLarge",
  component: ChevronLeftLarge,
};

export const Default = {
  args: {},
};
