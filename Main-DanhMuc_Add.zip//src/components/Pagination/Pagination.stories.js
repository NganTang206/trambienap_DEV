import { Pagination } from ".";

export default {
  title: "Components/Pagination",
  component: Pagination,
  argTypes: {
    length: {
      options: ["long", "short"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    length: "long",
    className: {},
  },
};
