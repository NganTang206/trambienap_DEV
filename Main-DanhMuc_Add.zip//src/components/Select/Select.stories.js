import { Select } from ".";

export default {
  title: "Components/Select",
  component: Select,
  argTypes: {
    stateProp: {
      options: ["default", "selected", "focus", "hover", "disabled"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    opened: true,
    compact: true,
    subtle: true,
    invalid: true,
    validated: true,
    loading: true,
    stateProp: "default",
    className: {},
    selectFieldFocusClassName: {},
    dropdownMenuClassName: {},
    placeholderClassName: {},
    text: "--Chọn--",
    hasDropdownMenu: true,
  },
};
