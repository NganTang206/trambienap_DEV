/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { ChevronRightLarge } from "../ChevronRightLarge";
import "./style.css";

export const StateDefaultWrapper = ({
  state,
  className,
  chevronRightLargeChevronRightLarge = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-right-large-3@2x.png",
}) => {
  return (
    <div className={`state-default-wrapper ${className}`}>
      <ChevronRightLarge
        chevronRightLarge={chevronRightLargeChevronRightLarge}
        className="chevron-right-large-instance"
      />
    </div>
  );
};

StateDefaultWrapper.propTypes = {
  state: PropTypes.oneOf(["disabled", "active", "default"]),
  chevronRightLargeChevronRightLarge: PropTypes.string,
};
