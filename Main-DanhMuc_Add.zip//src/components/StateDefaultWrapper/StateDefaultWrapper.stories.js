import { StateDefaultWrapper } from ".";

export default {
  title: "Components/StateDefaultWrapper",
  component: StateDefaultWrapper,
  argTypes: {
    state: {
      options: ["disabled", "active", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    state: "disabled",
    className: {},
    chevronRightLargeChevronRightLarge:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/chevron-right-large-3@2x.png",
  },
};
