import { Item } from ".";

export default {
  title: "Components/Item",
  component: Item,
  argTypes: {
    property1: {
      options: [
        "iht-default",
        "HT-default",
        "idm-selected",
        "idn-default",
        "DN-selected",
        "DN-default",
        "HT-selected",
        "DM-default",
        "idm-default",
        "idn-selected",
        "pass",
        "DM-selected",
        "change-pass",
        "changepass-hover",
        "iht-selected",
      ],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "iht-default",
    propertyHtClassName: {},
    bulkPropertyHeThong:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk@2x.png",
  },
};
