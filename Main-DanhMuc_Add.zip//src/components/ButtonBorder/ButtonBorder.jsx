/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { useReducer } from "react";
import { Linear } from "../Linear";
import "./style.css";

export const ButtonBorder = ({ icon, stateProp, spacing, loading, className, text = "Label" }) => {
  const [state, dispatch] = useReducer(reducer, {
    icon: icon || "none",
    state: stateProp || "default",
    spacing: spacing || "default",
    loading: loading || false,
  });

  return (
    <div
      className={`button-border state-5-${state.state} icon-0-${state.icon} spacing-1-${state.spacing} loading-4-${state.loading} ${className}`}
      onMouseEnter={() => {
        dispatch("mouse_enter");
      }}
      onMouseLeave={() => {
        dispatch("mouse_leave");
      }}
    >
      {state.icon === "before" && (
        <Linear
          className="linear-6"
          property1="ch-nh-s-a"
          propertyChNhSA="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear@2x.png"
        />
      )}

      {(state.icon === "before" || (!state.loading && state.icon === "none")) && <div className="label-3">{text}</div>}

      {(state.loading || state.icon === "only") && (
        <Linear
          className={`${
            !state.loading ? "linear-6" : state.spacing === "compact" && state.icon === "none" ? "class-6" : "class-7"
          }`}
          property1={state.icon === "none" ? "loading" : "more"}
          propertyLoading={
            state.loading && state.spacing === "default"
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-9@2x.png"
              : state.spacing === "compact" && state.icon === "none"
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-13@2x.png"
              : undefined
          }
          propertyMore={
            !state.loading
              ? "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/linear-3@2x.png"
              : undefined
          }
        />
      )}
    </div>
  );
};

function reducer(state, action) {
  switch (action) {
    case "mouse_enter":
      return {
        ...state,
        state: "hover",
      };

    case "mouse_leave":
      return {
        ...state,
        state: "default",
      };
  }

  return state;
}

ButtonBorder.propTypes = {
  icon: PropTypes.oneOf(["none", "only", "before"]),
  stateProp: PropTypes.oneOf(["hover", "active", "default"]),
  spacing: PropTypes.oneOf(["compact", "default"]),
  loading: PropTypes.bool,
  text: PropTypes.string,
};
