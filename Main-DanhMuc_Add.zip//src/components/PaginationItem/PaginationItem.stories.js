import { PaginationItem } from ".";

export default {
  title: "Components/PaginationItem",
  component: PaginationItem,
  argTypes: {
    state: {
      options: ["selected", "active", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    state: "selected",
    className: {},
    divClassName: {},
    text: "1",
  },
};
