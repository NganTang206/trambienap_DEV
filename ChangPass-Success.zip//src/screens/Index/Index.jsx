import React from "react";
import { ChangePassword } from "../../components/ChangePassword";
import { NavContentSidebar } from "../../components/NavContentSidebar";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="page-wrapper">
        <div className="page">
          <NavContentSidebar
            className="nav-content-sidebar-instance"
            itemBulkPropertyHeThong="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk-1@2x.png"
            itemProperty1="iht-selected"
            itemPropertyHtClassName="design-component-instance-node"
            logoEvnhcmcIcon="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af8262ded9bf6dcc605ac2/img/logo-evnhcmc-icon-4@2x.png"
            property1="default-close"
          />
          <div className="page-container">
            <header className="header">
              <div className="breadcrumbs">
                <div className="breadcrumb">
                  <div className="text-wrapper-5">Trang chủ</div>
                </div>
                <div className="breadcrumb">
                  <img
                    className="vector"
                    alt="Vector"
                    src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/vector@2x.png"
                  />
                  <div className="text-wrapper-5">Hệ Thống</div>
                </div>
                <div className="breadcrumb">
                  <img
                    className="vector"
                    alt="Vector"
                    src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/vector@2x.png"
                  />
                  <div className="text-wrapper-5">Thay đổi mật khẩu</div>
                </div>
              </div>
              <div className="main-content">
                <div className="text-wrapper-6">Thay đổi mật khẩu</div>
              </div>
            </header>
            <div className="change-password-wrapper">
              <ChangePassword
                className="change-password-instance"
                ellipse="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af8262ded9bf6dcc605ac2/img/ellipse-1-1@2x.png"
                intersectClassName="change-password-2"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
