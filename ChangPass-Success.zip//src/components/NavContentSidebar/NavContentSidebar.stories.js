import { NavContentSidebar } from ".";

export default {
  title: "Components/NavContentSidebar",
  component: NavContentSidebar,
  argTypes: {
    property1: {
      options: ["change-pass", "default-close", "default-open"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    showLayers: true,
    property1: "change-pass",
    className: {},
    logoEvnhcmcIcon:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/logo-evnhcmc-icon@2x.png",
    itemProperty1: "iht-default",
    itemBulkPropertyHeThong:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af7ccd60662165d0b3c07e/img/bulk@2x.png",
    itemPropertyHtClassName: {},
  },
};
