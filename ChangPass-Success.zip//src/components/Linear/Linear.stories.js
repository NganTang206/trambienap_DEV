import { Linear } from ".";

export default {
  title: "Components/Linear",
  component: Linear,
  argTypes: {
    property1: {
      options: ["add", "login", "security-safe", "more", "ch-nh-s-a", "loading", "search"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "add",
    className: {},
  },
};
