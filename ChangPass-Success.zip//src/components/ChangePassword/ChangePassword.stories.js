import { ChangePassword } from ".";

export default {
  title: "Components/ChangePassword",
  component: ChangePassword,
};

export const Default = {
  args: {
    className: {},
    intersectClassName: {},
    ellipse:
      "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af8262ded9bf6dcc605ac2/img/ellipse-1@2x.png",
  },
};
