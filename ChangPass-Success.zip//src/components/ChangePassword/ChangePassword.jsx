/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const ChangePassword = ({
  className,
  intersectClassName,
  ellipse = "https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af8262ded9bf6dcc605ac2/img/ellipse-1@2x.png",
}) => {
  return (
    <div className={`change-password ${className}`}>
      <div className="overlap">
        <div className="lock">
          <div className="rectangle-2" />
          <img
            className={`intersect ${intersectClassName}`}
            alt="Intersect"
            src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af8262ded9bf6dcc605ac2/img/intersect@2x.png"
          />
          <img className="ellipse" alt="Ellipse" src={ellipse} />
        </div>
        <div className="overlap-group-wrapper">
          <div className="overlap-group">
            <div className="rectangle-3" />
            <div className="ellipse-2" />
            <div className="ellipse-3" />
            <div className="ellipse-4" />
            <div className="ellipse-5" />
            <div className="ellipse-6" />
            <img
              className="ellipse-7"
              alt="Ellipse"
              src="https://cdn.animaapp.com/projects/65af7cb4af06a9ea2eca5fca/releases/65af8262ded9bf6dcc605ac2/img/ellipse-12@2x.png"
            />
          </div>
        </div>
      </div>
      <p className="search-not-found">Thay đổi mật khẩu thành công</p>
    </div>
  );
};

ChangePassword.propTypes = {
  ellipse: PropTypes.string,
};
