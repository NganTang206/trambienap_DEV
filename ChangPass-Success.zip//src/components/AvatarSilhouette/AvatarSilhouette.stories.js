import { AvatarSilhouette } from ".";

export default {
  title: "Components/AvatarSilhouette",
  component: AvatarSilhouette,
  argTypes: {
    size: {
      options: [
        "twenty-four-px",
        "ninety-six-px",
        "sixteen-px",
        "forty-px",
        "one-hundred-and-twenty-eight-px",
        "thirty-two-px",
      ],
      control: { type: "select" },
    },
    status: {
      options: ["none"],
      control: { type: "select" },
    },
    presence: {
      options: ["online", "none"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    size: "twenty-four-px",
    status: "none",
    presence: "online",
    className: {},
    presenceClassName: {},
  },
};
