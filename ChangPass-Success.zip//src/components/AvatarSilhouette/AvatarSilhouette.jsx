/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const AvatarSilhouette = ({ size, status, presence, className, presenceClassName }) => {
  return (
    <div className={`avatar-silhouette ${size} ${className}`}>
      {presence === "online" && <div className={`presence ${presenceClassName}`} />}
    </div>
  );
};

AvatarSilhouette.propTypes = {
  size: PropTypes.oneOf([
    "twenty-four-px",
    "ninety-six-px",
    "sixteen-px",
    "forty-px",
    "one-hundred-and-twenty-eight-px",
    "thirty-two-px",
  ]),
  status: PropTypes.oneOf(["none"]),
  presence: PropTypes.oneOf(["online", "none"]),
};
